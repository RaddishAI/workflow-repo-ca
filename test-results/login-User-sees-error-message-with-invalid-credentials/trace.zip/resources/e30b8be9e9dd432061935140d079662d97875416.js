export function updateTitle(newTitle) {
  document.title = newTitle;
}
