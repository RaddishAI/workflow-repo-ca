export const CONFIG = {
  apiUrl: 'https://api.noroff.dev/api/v1/holidaze/',
};
