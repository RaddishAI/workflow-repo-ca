const MESSAGES = {
  en: {
    registrationSuccess: 'Registration successful!',
    invalidationError: 'Invalid input',
  },
};

export default MESSAGES;
